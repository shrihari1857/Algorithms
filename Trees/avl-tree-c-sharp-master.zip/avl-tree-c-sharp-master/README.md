AVL Tree in C#
==============

This is the C# source code that accompanies the bitlush article: https://bitlush.com/blog/efficient-avl-tree-in-c-sharp
